import pandas as pd
import requests
from tqdm import tqdm
import geopandas

#주소 변환 함수
#주소 변환 함수
def get_juso(data):
    df=pd.DataFrame()
    for i in tqdm(range(len(data))):
        adress = data.juso[i]
        url = f'https://dapi.kakao.com/v2/local/search/address.json?query={adress}'
        headers = {
        ## 여러분의 카카오 API의 REST API키를 아래 예시와 같이 입력해주세요
        ## "Authorization": "KakaoAK REST API키 입력 gogo"}
        "Authorization": "KakaoAK 1358366e6234ef1b494f623fa9b7fd03"}
        response = requests.get(url, headers = headers).json()
        try : 
            roadAddr = response.get('documents')[0].get('road_address').get('address_name')
            jibunAddr = response.get('documents')[0].get('address').get('address_name')
            emdNm =response.get('documents')[0].get('road_address').get('region_3depth_name')
            x = response.get('documents')[0].get('address').get('x')
            y = response.get('documents')[0].get('address').get('y')
            temp = pd.DataFrame({
                'input_adress' : data.draddr[i],
                'roadAddr' : roadAddr,
                'jibunAddr' : jibunAddr,
                'emdNm':emdNm,
                'x' : x,
                'y' : y
            },index=[0])
            
        except:
            roadAddr = 'error'
            jibunAddr = 'error'
            emdNm = 'error'
            x = 'error',
            y = 'error'
            temp = pd.DataFrame({
                'input_adress' : adress,
                'roadAddr' : roadAddr,
                'jibunAddr' : jibunAddr,
                'emdNm':emdNm,
                'x' : x,
                'y' : y
            },index=[0])
        df = pd.concat([df,temp])
    return df

def main():
    #data 받아오기
    input_data = pd.read_csv('./input_data.csv',encoding='utf8')
    #공백행 "-" 로 대체
    input_data = input_data.fillna('-')
    #빈 도로명 주소 지번 주소로 추가
    for i in range(len(input_data.draddr)):
        if input_data.draddr[i] == "-":
            input_data.draddr[i] = input_data.jiaddr[i]

    #데이터 전처리
    data = input_data.filter(items=['draddr','jiaddr'])
    data['juso'] = data.draddr.apply(lambda x : NM_si + " " + x)

    #함수실행
    df = get_juso(data).reset_index(drop=True)

    #결과값 추출
    out_put = pd.merge(input_data, df, left_on='draddr',right_on='input_adress', how='left' ).drop(columns=['input_adress'])
    out_put = out_put.fillna("error")
    out_error = out_put.query('roadAddr == "error"')
    out_tr = out_put.query('roadAddr != "error"')

    #shp 파일 생성
    gdf = geopandas.GeoDataFrame(out_tr,geometry=geopandas.points_from_xy(out_tr.x, out_tr.y))
    gdf.crs= "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"
    gdf.to_file('./result.shp', driver='ESRI Shapefile')
    #error 파일 생성
    out_error.to_csv('./error_data.csv', index=False, encoding='utf-8-sig')

if (__name__=="__main__"):
    API_KEY = input("API_KEY를 입력하세요 : ")
    NM_si = input("지자체 명을 입력하세요 : ")
    if API_KEY == True:
        API_KEY = API_KEY
    else: 
        API_KEY = '1358366e6234ef1b494f623fa9b7fd03'

    main()

