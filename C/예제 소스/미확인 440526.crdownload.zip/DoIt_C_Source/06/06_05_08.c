#include <stdio.h>

void main()
{
    float data = 12.34f;
    printf("%f, %e, %E", data, data, data);
}