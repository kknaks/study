#include <stdio.h>

void main()
{
    float value = 2.1f;
    printf("%f", value);
}