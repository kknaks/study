def openBox() :
	print("종이 상자를 엽니다. ^^")
	openBox()

openBox()	# 처음 함수를 다시 호출
