#include <stdio.h>

void main()
{
    short student[20];

    student[1] = 10;
    printf("%d\n", student[1]);
}