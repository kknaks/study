#include <stdio.h>

void main()
{
    char data = -1;
    printf("%d, %u", data, data);
}