#include <stdio.h>

void main()
{
    short student[20];

    student[1] = 10;
    printf("%d %d\n", student[1], student[2]);
}