#include <stdio.h>

void main()
{
    putchar('H');
    putchar('i');
    putchar('~');
}